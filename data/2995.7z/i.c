<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<HTML><HEAD>
<TITLE>300 Multiple Choices</TITLE>
</HEAD><BODY>
<H1>Multiple Choices</H1>
The document name you requested (<code>/year2007/i.c</code>) could not be found on this server.
However, we found documents with names similar to the one you requested.<p>Available documents:
<ul>
<li><a href="/year2007/a.c">/year2007/a.c</a> (mistyped character)
<li><a href="/year2007/b.c">/year2007/b.c</a> (mistyped character)
<li><a href="/year2007/c.c">/year2007/c.c</a> (mistyped character)
<li><a href="/year2007/d.c">/year2007/d.c</a> (mistyped character)
<li><a href="/year2007/f.c">/year2007/f.c</a> (mistyped character)
<li><a href="/year2007/h.c">/year2007/h.c</a> (mistyped character)
</ul>
Furthermore, the following related documents were found:
<ul>
<li><a href="/year2007/i.pdf">/year2007/i.pdf</a> (common basename)
<li><a href="/year2007/i.cpp">/year2007/i.cpp</a> (common basename)
<li><a href="/year2007/i.in">/year2007/i.in</a> (common basename)
<li><a href="/year2007/i.out">/year2007/i.out</a> (common basename)
</ul>
</BODY></HTML>
