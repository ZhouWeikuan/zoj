<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<HTML><HEAD>
<TITLE>300 Multiple Choices</TITLE>
</HEAD><BODY>
<H1>Multiple Choices</H1>
The document name you requested (<code>/year2007/g.c</code>) could not be found on this server.
However, we found documents with names similar to the one you requested.<p>Available documents:
<ul>
<li><a href="/year2007/a.c">/year2007/a.c</a> (mistyped character)
<li><a href="/year2007/b.c">/year2007/b.c</a> (mistyped character)
<li><a href="/year2007/c.c">/year2007/c.c</a> (mistyped character)
<li><a href="/year2007/d.c">/year2007/d.c</a> (mistyped character)
<li><a href="/year2007/f.c">/year2007/f.c</a> (mistyped character)
<li><a href="/year2007/h.c">/year2007/h.c</a> (mistyped character)
</ul>
Furthermore, the following related documents were found:
<ul>
<li><a href="/year2007/g.pdf">/year2007/g.pdf</a> (common basename)
<li><a href="/year2007/g.cpp">/year2007/g.cpp</a> (common basename)
<li><a href="/year2007/g.in">/year2007/g.in</a> (common basename)
<li><a href="/year2007/g.out">/year2007/g.out</a> (common basename)
</ul>
</BODY></HTML>
