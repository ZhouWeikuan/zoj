/* Generate a nullary program to sort the contents of registers
 * A..X, assuming Y=Z=0.
 */
#include <cstdio>

void order(char A, char B) {
  char a = A + 'a'-'A', b = B + 'b'-'B';
  printf("%c(Y%c(Z)%c)z(%cz)y(%cy)", a, b, a, A, B);
}

int main(void) {
  for (int i = 0; i < 24; ++i)
    for (int j = i+1; j < 24; ++j)
      order('A'+i, 'A'+j);
  return 0;
}
