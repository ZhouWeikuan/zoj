/*
 * Writes a nullary program for sorting between 2 and 24 numbers 
 * (number given in argv[1]) to standard output.
 *
 * Uses Batcher's bitonic sort to construct a sorting network.
 * Most easily implemented for powers of 2
 * Add dummy registers up to 2^5 registers. The dummy registers contain 
 * "infinity".
 * Important observation:
 *    "Since compswap is always called with the second index larger 
 *     than the first, the "infinity" values never move." 
 * Thus, we know the outcome of 
 * every comparison involving a dummy register. Hence, we don't need 
 * to write them out.
 *             /Mikael Goldmann
 */

#include<stdio.h>
#include<ctype.h>
#include<assert.h>

int BOUND;

void compswap(int  r1, int  r2) 
{
  char A,B;
  char a,b;  
  assert(r1 < r2);
  if (r2 >= BOUND) return;  
  a = r1 + 'a';
  b = r2 + 'a';
  A = toupper(a);
  B = toupper(b);

  /* a(Yb(Zyy)y(Ba)a)z(ABz) */
  printf("%c(Y%c(Zyy)y(%c%c)%c)z(%c%cz)", a, b, B,a, a, A, B);  

  fprintf(stderr, "%c <= %c\n", a, b);
  
}




// len is power of 2
void bitonicsort(int pos, int len) 
{
  int len2 = len/2;  
  int lo,hi;
  if (len<2) return;
  lo = 0;
  hi = len2;
  while (hi<len) compswap(pos+(lo++), pos+(hi++));      
  bitonicsort(pos, len2);
  bitonicsort(pos+len2, len2);
}

// len is power of 2
void sortup(int pos, int len) 
{
  int len2 = len/2;  
  int lo,hi;
  if (len < 2) return;
  sortup(pos, len2);
  sortup(pos+len2, len2);
  lo = 0;
  hi = len-1;    
  while (lo<hi) compswap(pos+(lo++),pos+(hi--));
  bitonicsort(pos, len2);
  bitonicsort(pos+len2, len2);  
}

void makesort(int n) 
{
  int m=1;  
  BOUND=n;
  while (m < n) m<<=1;
  sortup(0,m);  
}

    
int main(int argc, char **argv)
{
  int n;
  
  if (argc == 2 && sscanf(argv[1], "%d", &n) && n > 1 && n < 25)
    /* then use this value for n */ ;
  else 
    n = 24;   
  makesort(n);  
  printf("\n");

}
