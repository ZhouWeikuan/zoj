#!/usr/bin/python

import re
import sys

DEBUG = False

c = [chr(i + ord('a')) for i in xrange(26)]
C = [chr(i + ord('A')) for i in xrange(26)]

def bubble(s, e):
    p = ''
    for j in xrange(s, e - 1):
        for i in xrange(s, e - 1 - j + s):
            p += swapmin(i, i + 1)
    return p

def swapmin(i, j):
    return c[i]+'(Y'+c[j]+'(Z)'+c[i]+')z('+C[i]+'z)y('+C[j]+'y)'

print bubble(0, 24)
