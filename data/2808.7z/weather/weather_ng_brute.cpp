/*
 * Sample solution for "Worst Weather Ever".
 *
 * Brute force solution using map<int,int>. 
 *
 * Running time: O(n m).
 *
 * Author: Nils Grimsmo
 */

#include <cstdio>
#include <vector>
#include <iostream>
#include <ext/hash_map>
#include <map>

using namespace std;
using namespace __gnu_cxx;

#define OUT(X) cerr << __STRING(X) << "=" << X << endl

typedef map<int,int>::iterator mit;

int main()
{
    for (int cas = 0; ; cas++) {
        int n, m;
        scanf("%d", &n);
        map<int,int> index;
        for (int i = 0; i < n; i++) {
            int year, rain;
            scanf("%d %d", &year, &rain);
            index[year] = rain;
        }
        scanf("%d", &m);
        if (n == 0 && m == 0) {
            return 0;
        }
        else if (cas) {
            printf("\n");
        }
        for (int j = 0; j < m; j++) {
            bool done = false;
            int Y, X;
            scanf("%d %d", &Y, &X);
            mit yi = index.lower_bound(Y);
            mit xi = index.lower_bound(X);
            bool yf = (yi != index.end() && Y == yi->first);
            bool xf = (xi != index.end() && X == xi->first);
            if (yf && xf && yi->second < xi->second) {
                printf("false\n");
                continue;
            }
            if (xi != yi) {
                mit it = yi;
                if (yf) it++;
                for ( ; it != index.end() && it->first < X; ++it) {
                    if ((xf && it->second >= xi->second) ||
                            (!xf && yf && yi->second <= it->second)) {
                        printf("false\n");
                        done = true;
                        break;
                    }
                }
            }
            if (done) continue;
            if (xf && xi->second == 0 && Y + 1 == X) {
                printf("true\n");
                continue;
            }
            if (!yf || !xf) {
                printf("maybe\n");
                continue;
            }
            for (mit it = yi; it != xi; ) {
                if (it->first + 1 != (++it)->first) {
                    printf("maybe\n");
                    done = true;
                    break;
                }
            }
            if (done) continue;
            printf("true\n");
        }
    }
}
