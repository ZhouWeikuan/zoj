
my $i=0;
open(INPUT, "> input");
open(OUTPUT, "> output");
print INPUT "10\n";
for ($i=0; $i<10; $i++){
    open(FI, "<FBI/FBI$i.IN");
    open(FO, "<FBI/FBI$i.OUT");
    if ($i){
        print INPUT "\n";
        print OUTPUT "\n";
    }
    print INPUT <FI>;
    print OUTPUT <FO>;
    close(FI);
    close(FO);
}

