/* SWERC 97
   Problem D: Video Surveillance
   Autor: Falk Bartels
   Date: 19.11.97
*/

#include <stdio.h>

#define PMAX 100

FILE *input;
int n;
int px[PMAX], py[PMAX];

int readcase()
{
  int l;

  fscanf( input, " %d", &n );
  if (n==0) return 0;

  for (l=0; l<n; l++) fscanf( input, " %d %d", &px[l], &py[l]);

  return 1;
}

void solvecase( int kase )
{
  int east, west, north, south, l;

  /* find maximal coordinates for every direction
     => enclosing rectangle */
  east=px[0], west=px[0], north=py[0], south=py[0];
  for (l=1; l<n; l++) {
    if (east<px[l]) east=px[l];
    if (west>px[l]) west=px[l];
    if (north<py[l]) north=py[l];
    if (south>py[l]) south=py[l];
  }

  for (l=0; l<n; l++) {
    if (px[l]<px[(l+1)%n] && north>py[l]) north=py[l]; /* northern bound */
    if (px[l]>px[(l+1)%n] && south<py[l]) south=py[l]; /* southern bound */
    if (py[l]<py[(l+1)%n] && west<px[l]) west=px[l]; /* western bound */
    if (py[l]>py[(l+1)%n] && east>px[l]) east=px[l]; /* eastern bound */
  }

  printf("Floor #%d\n", kase);
  printf("Surveillance is %spossible.\n\n",
         (north>=south && east>=west)?"":"im");
}

int main()
{
  int kase = 0;

  if ((input=fopen("video.in", "r"))==NULL) {
    printf("No Inputfile\n");
    return 1;
  }

  while (readcase()) solvecase( ++kase);

  return 0;
}
