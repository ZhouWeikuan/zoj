#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#define MAXN 1000000
#define MAXVAL 2000000000

int m,n;
int val[MAXN+2];
int inseq[MAXN+2];
int sol[MAXN+2];


typedef struct HeapElement
{
	int val, where;
} HeapElement;

int heap_size;
struct HeapElement heap[MAXN+2];


int compare_heap_elements(HeapElement el1, HeapElement el2)
{
	if(el1.val<el2.val) return 1;
	return -1;
}

int heap_delete_min()
{
	int i, tmpel;
	int ret;
	HeapElement el0;
	
	assert(heap_size > 0);
	ret = heap[1].where;
	heap_size--;
	if(heap_size==0) return ret;
	
	heap[1] = heap[heap_size+1];
	for(i=1;i<=heap_size;)
	{
		el0 = heap[i];
		if(2*i>heap_size) break;
		if(2*i+1>heap_size || compare_heap_elements(heap[2*i], heap[2*i+1])>=0) tmpel = 2*i;
		else tmpel = 2*i+1;

		if(compare_heap_elements(heap[tmpel], el0)>0) 
		{ 
			heap[i] = heap[tmpel]; heap[tmpel] = el0; 
		}
		else break;
		i = tmpel;
	}
	return ret;
}

void heap_add(int val, int where)
{
	int i;
	HeapElement el;

	heap_size++;
	heap[heap_size].val = val;
	heap[heap_size].where = where;
	for(i=heap_size;i>=1;i>>=1)
	{
		if((i>>1) < 1) break;
		if(compare_heap_elements(heap[i>>1], heap[i])>=0) break;
		el = heap[i]; heap[i] = heap[i>>1];	heap[i>>1] = el;
	}
}

void heap_init()
{
	heap_size = 0;
}


int bin_search(int what, int b, int e)
{
	int newpos;

	if(b>=e-1) return b;
	
	newpos = (b+e)/2;
	if(val[newpos]<=what) return bin_search(what,newpos+1,e);
	else if(newpos==0 || val[newpos-1]<=what) return newpos;
	else return bin_search(what,b,newpos);
}


int main(void)
{
	int i,j,place,cur;
	
	while(1)
	{
		scanf(" %d %d ", &n, &m);
		if(m==0 && n==0) break;
		if(m>n) m=n;
		heap_init();
		for(i=0;i<m;i++) val[i]=-1;
		val[m]=MAXVAL;
		for(i=0;i<n;i++) scanf(" %d ", &inseq[i]);
		for(i=0;i<n;i++)
		{
			cur = inseq[i];
			place = bin_search(cur,0,m+1)-1;
/*printf("%d %d\n", cur, place);*/
			if(place==-1) { printf("Transportation failed\n"); break; }
			sol[i] = place;
			val[place] = cur;
			heap_add(cur, place);
/*for(j=0;j<m;j++) printf("%d ",val[j]);
printf("\n");*/
		}
		if(i<n) continue;
		for(i=0;i<n;i++)
		{
			printf("%d", sol[i]+1);
			if(i+1<n) printf(" "); else printf("\n");
		}
		for(i=0;i<n;i++)
		{
			printf("%d", heap_delete_min()+1);
			if(i+1<n) printf(" "); else printf("\n");
		}
	}
	return 0;
}
	


