import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.StringTokenizer;

public class calendar {
	StringTokenizer st = new StringTokenizer("");
	BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) throws Exception {
		new calendar().run();
	}
	String nextToken() throws Exception {
		while (!st.hasMoreTokens()) st = new StringTokenizer(input.readLine());
		return st.nextToken();
	}
	int nextInt() throws Exception {
		return Integer.parseInt(nextToken());
	}

	static final int LIM = 9;
	
	Map moves = new HashMap();
	LinkedList queue = new LinkedList();

	private Object makeKey(int[] a) {
		long x = 0;
		for (int i = 0; i < LIM; ++i) x = x * LIM + a[i];
		return Long.valueOf(x);
	}
	
	private void fromKey(Object o, int[] a) {
		long x = ((Long)o).longValue();
		for (int i = LIM; --i >= 0; ) {
			a[i] = (int) (x % LIM);
			x /= LIM;
		}
	}

	private void generate() throws Exception {
		int[] a = new int[LIM];
		for (int i = 0; i < LIM; ++i) a[i] = i;
		Object k = makeKey(a);
		moves.put(k, Integer.valueOf(0));
		queue.addLast(k);
		while (!queue.isEmpty()) {
			fromKey(queue.removeFirst(), a);
			for (int i = 2; i <= LIM; ++i) {
				reverse(a, i);
				k = makeKey(a);
				reverse(a, i);
				if (moves.containsKey(k)) continue;
				moves.put(k, Integer.valueOf(i));
				queue.addLast(k);
			}
		}
	}

	int size;
	int[] orig = new int[60];
	int[] perm = new int[60];

	private int find(int[] a, int n, int x) {
		for (int i = 0; i < n; ++i)
			if (a[i] == x) return i;
		return n; // should never happen
	}

	private void run() throws Exception {
		generate();
		for (;;) {
			size = nextInt();
			if (size <= 0) break;
			for (int i = 0; i < size; ++i) orig[i] = nextInt();
			for (int i = 0; i < size; ++i) {
				int x = nextInt();
				int p = find(orig, size, x);
				perm[p] = i;
				orig[p] = -1;
			}
			int cnt;
			if (size < LIM) {
				cnt = solve(1);
			} else {
				cnt = solve(LIM);
				cnt = solve9(cnt);
			}
			if (cnt == 0) System.out.print("1");
			System.out.println();
		}
	}

	private int solve(int stop) {
		int cnt = 0;
		for (int i = size; --i >= stop; ) {
			int p = find(perm, i+1, i);
			if (p == i) continue;
			if (p > 0) {
				reverse(perm, p+1);
				if (cnt++ > 0) System.out.print(' ');
				System.out.print(p+1);
			}
			if (i > 0) {
				reverse(perm, i+1);
				if (cnt++ > 0) System.out.print(' ');
				System.out.print(i+1);
			}
		}
		return cnt;
	}
	
	private void dumpPerm() {
		System.out.print("    ->");
		for (int i=0; i < size; ++i) System.out.print(" " + perm[i]);
		System.out.println();
	}
	private int solve9(int cnt) {
		for (;;) {
			Object k = makeKey(perm);
			Integer mm = ((Integer)moves.get(k));
			if (mm == null) System.err.println(">>> " + k);
			int m = mm.intValue();
			if (m == 0) return cnt;
			reverse(perm, m);
			if (cnt++ > 0) System.out.print(' ');
			System.out.print(m);
		}
	}

	private void reverse(int[] a, int cnt) {
		int x;
		for (int i = 0; i < cnt/2; ++i) {
			x = a[i];
			a[i] = a[cnt-1-i];
			a[cnt-1-i] = x;
		}
	}
}
