#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

/*#define DEBUG_PRINTS */

#define MAXN 40
#define MAXBF 1000000 

int n;
int seq[MAXN+2];
int next[MAXBF+2], nflip[MAXBF+2];
int inq[MAXBF+2];
int q[MAXBF+2], qb,qe;

void print_seq()
{
#ifdef DEBUG_PRINTS
	int i;
	for(i=0;i<n;i++) printf("%2d ", seq[i]);
	printf("\n");
#endif
}

void print_flip(int l)
{
#ifdef DEBUG_PRINTS
	printf("flip %d\n",l);
#else
	printf("%d ",l);
#endif
}

int perm2ind(int *p, int plen) /* serazene lexikograficky */
{
	int i,j,ret,pom;
	int pouz[MAXN+2];

	for(i=0;i<plen;i++) pouz[i]=0;
	ret=0;
	for(i=0;i<plen;i++)
	{
		pom=0;
		for(j=0;j<p[i];j++) if(!pouz[j]) pom++;
		ret=ret*(plen-i)+pom;
		pouz[p[i]]=1;
	}
	
	return ret;
}

void ind2perm(int apuv,int *p, int plen)
{
	int i,j,pom,a=apuv;
	int pouz[MAXN+2], kt[MAXN+2];

	for(i=0;i<plen;i++) pouz[i]=0;
	for(i=plen-1;i>=0;i--) { kt[i]=a%(plen-i); a/=(plen-i); }
	for(i=0;i<plen;i++)
	{
		pom=kt[i];
		for(j=0;j<plen && pom>0;j++) if(!pouz[j]) pom--;
		while(pouz[j]) j++;
		p[i]=j;
		pouz[j]=1;
	}
}
	
void flip(int *p, int flen)
{
	int i,tmp;
	
	for(i=0;i<flen/2;i++)
	{
		tmp = p[i]; p[i] = p[flen-i-1]; p[flen-i-1] = tmp;
	}
}


int main(int argc, char *argv[])
{
	int i,j,tmp;
	int ins1[MAXN+2], ins2[MAXN+2], used2[MAXN+2];
	int tmpseq[MAXN+2];

	inq[0] = 1;
	q[0]=0; qe = 1; qb = 0;
	next[0]=-1;
	while(qe!=qb)
	{
		ind2perm(q[qb], tmpseq, 9);
		for(i=1;i<=9;i++)
		{
			flip(tmpseq,i);
			tmp = perm2ind(tmpseq,9);
			if(!inq[tmp]) 
			{
				q[qe++] = tmp;
				inq[tmp] = 1;
				next[tmp] = q[qb];
				nflip[tmp] = i;				
			}
			flip(tmpseq,i);
		}
		qb++;
	}
	
	while(1)
	{
		scanf("%d", &n);
		if(n==0) break;
		for(i=0;i<n;i++) scanf("%d",&ins1[i]);
		for(i=0;i<n;i++) scanf("%d",&ins2[i]);
		for(i=0;i<n;i++) used2[i]=0;
		for(i=0;i<n;i++) 
		{
			for(j=0;j<n;j++) if(!used2[j] && ins1[i]==ins2[j]) break;
			seq[i] = j;
			used2[j] = 1;
		}
		print_seq();
		while(n!=9 && n>0)
		{
			for(i=0;i<n;i++) if(seq[i]==n-1) break;
			flip(seq,i+1); flip(seq,n);
			print_flip(i+1);
			print_flip(n);
			n--;
			print_seq();
		}
		if(n==9)
		{
			tmp = perm2ind(seq,n);
			while(next[tmp]!=-1)
			{
				print_flip(nflip[tmp]);
				tmp = next[tmp];
				ind2perm(tmp,seq,9);
				print_seq();
			}
		}
		printf("\n");
	}	
	return 0;
}
