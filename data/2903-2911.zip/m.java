import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class money
{
	static final int INF = 10000000;

	StringTokenizer st = new StringTokenizer("");
	BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	int[] cust = new int[1000099];
	int[] shop = new int[1000099];
	int amount;
	int max;

	public static void main(String[] args) throws Exception {
		new money().run();
	}
	
	private int parse() throws Exception {
		if (!st.hasMoreTokens()) st = new StringTokenizer(input.readLine());
		String s = st.nextToken();
		int i = s.indexOf('.');
		if (i < 0) return Integer.parseInt(s) * 100;
		int r = Integer.parseInt(s.substring(0, i)) * 100;
		int d = Integer.parseInt(s.substring(i+1));
		return r + ((i + 2 == s.length()) ? d * 10 : d);
	}

	private int parseCnt() throws Exception {
		if (!st.hasMoreTokens()) st = new StringTokenizer(input.readLine());
		String s = st.nextToken();
		return Integer.parseInt(s.substring(0, s.length()-1));
	}

	private void run() throws Exception {
		for (;;) {
			amount = parse();
			if (amount < 0) return;
			possible(cust);
			int mc = max;
			possible(shop);
			int ms = max;
			int best = INF;
			for (int i = 0; i <= ms && i+amount <= mc; ++i) {
				if (shop[i] + cust[i+amount] < best) {
					best = shop[i] + cust[i+amount];
				}
			}
			System.out.println(best < INF
					? best + " tenders must be exchanged."
					: "The payment is impossible.");
		}
	}

	private void possible(int[] pos) throws Exception {
		Arrays.fill(pos, INF);
		pos[0] = 0;
		max = 0;
		for (;;) {
			int nom = parse();
			if (nom < 0) break;
			int cnt = parseCnt();
			while (cnt-- > 0) {
				for (int i = max; i >= 0; --i)
					if (pos[i] < INF) {
						makePossible(pos, i+nom, pos[i] + 1);
					}
			}
		}
	}

	private void makePossible(int[] pos, int i, int dist) {
		if (pos[i] < dist) return;
		pos[i] = dist;
		if (i > max) max = i;
	}
}
