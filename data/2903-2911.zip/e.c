
#include <stdio.h>
#include <stdlib.h>

static unsigned vars[10];
static int result, ano;
static char op;
static int lhs;
static char buf = -1;
static int dval[255]={['I'] = 1, ['V'] = 5, ['X'] = 10, ['L'] = 50, ['C'] = 100, ['D'] = 500, ['M'] = 1000};

static void
wrong_input (void)
{
  printf ("The input is incorrect!\n");
  exit (1);
}

static char
peek(void)
{
  if (buf == -1)
    {
      buf = getchar ();
      if (buf == -1)
	buf = '\n';
    }

  return buf;
}

static char
next (void)
{
  char c = peek ();
  buf = -1;
  return c;
}

static void
skip_to_eol (void)
{
  while (peek () != '\n')
    next ();
  next ();
}

static int
execute (void)
{
  if(ano < -1000) result -= 100000;
  else if (op == '+')
    result += ano;
  else
    result -= ano;

  ano = 0;
  /*
  if (result < 0 || result > 10000)
    {
      skip_to_eol ();
      printf ("Error\n");
      return 0;
    }
  */
  
  return 1;
}

static void
parse_roman (void)
{
  char c, n;

  while (1)
    {
      c = peek ();
      if (!dval[c])
	return;
      next ();

      n = peek ();
      if (dval[c] < dval[n])
	{
	  next ();
	  ano += dval[n] - dval[c];
	}
      else
	ano += dval[c];

      if  (ano > 10000)
	return;
    }
}

static void
prom (int *x, int b, const char *c)
{
  while ((*x) >= b)
    {
      printf ("%s", c);
      (*x) -= b;
    }
}

static void
print_roman (int x)
{
  if (x == 0)
    {
      printf ("O");
      return;
    }
  putchar('[');
  prom (&x, 1000, "M");
  prom (&x, 900, "CM");
  prom (&x, 500, "D");
  prom (&x, 400, "CD");
  prom (&x, 100, "C");
  prom (&x, 90, "XC");
  prom (&x, 50, "L");
  prom (&x, 40, "XL");
  prom (&x, 10, "X");
  prom (&x, 9, "IX");
  prom (&x, 5, "V");
  prom (&x, 4, "IV");
  prom (&x, 1, "I");
  putchar(']');
}

static void
assign (void)
{
  vars[lhs] = result;

  printf ("%d=", lhs);
  print_roman (result);
  printf ("\n");
}

static void
skip (const char *c)
{
  while (*c)
    {
      if (peek() != *c)
	wrong_input ();

      next ();
      c++;
    }
}

static void
reset (void)
{
  int i;

  for (i = 0; i < 10; i++)
    vars[i] = -100000;
}

static int
parse_line (void)
{
  char c;

  op = '+';
  result = 0;
  ano = 0;

  c = peek ();
  if ('0' <= c && c <= '9')
    {
      lhs = c - '0';
      next ();
      skip ("=");
    }
  else if (c == 'R')
    {
      skip("RESET\n");
      reset ();
      printf ("Ready\n");
      return 0;
    }
  else if (c == 'Q')
    {
      skip("QUIT");
      printf ("Bye\n");
      return 1;
    }

  while (1)
    {
      c = peek ();

      if (c == '\n')
	{
	  if (result <= 0 || result > 10000) {
	    printf("Error\n");
	  } else {
      	    assign ();
          }
	  next ();
	  return 0;
	}

      if ('0' <= c && c <= '9')
	{
	  ano = vars[c-'0'];
	  next ();
	  if (!execute ())
	    return 0;
	}
      else if (dval[c] > 0)
	{
	  parse_roman ();
	  if (!execute ())
	    return 0;
	}
      else if (c == '+' || c == '-')
	{
	  op = c;
	  next ();
	}
      else
	wrong_input ();
    }
}

int
main(void)
{
  reset ();

  while (1)
    if (parse_line())
        return 0;
}

