import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

public class soccer {
	StringTokenizer st = new StringTokenizer("");
	BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) throws Exception {
		new soccer().run();
	}
	String nextToken() throws Exception {
		while (!st.hasMoreTokens()) st = new StringTokenizer(input.readLine());
		return st.nextToken();
	}
	int nextInt() throws Exception {
		return Integer.parseInt(nextToken());
	}
	void outch(char ch) {System.out.print(ch);}
	void outln() {System.out.println();}

	static class Team {
		String name;
		int idx;
		int played, won, lost, tie;
		int points;
		int scplus, scminus;
	}
	
	Team[] teams;
	Map names = new HashMap();
	String[][] scores;
	int longest;

	private void run() throws Exception {
		for (;;) {
			int n = nextInt();
			if (n <= 0) break;
			longest = 0;
			teams = new Team[n];
			scores = new String[n][n];
			for (int i = 0; i < teams.length; ++i) {
				teams[i] = new Team();
				teams[i].name = nextToken();
				teams[i].idx = i;
				names.put(teams[i].name, teams[i]);
				if (teams[i].name.length() > longest)
					longest = teams[i].name.length();
			}
			n = nextInt();
			for (int i = 0; i < n; ++i) {
				readGame();
			}
			printTable();
			sortTeams();
			printRank();
		}
	}
	
	private void sortTeams() {
		Arrays.sort(teams, new Comparator(){
			public int compare(Object o1, Object o2) {
				Team t1 = (Team) o1, t2 = (Team) o2;
				if (t1.points != t2.points) return t2.points - t1.points;
				int d1 = t1.scplus - t1.scminus;
				int d2 = t2.scplus - t2.scminus;
				if (d1 != d2) return d2 - d1;
				if (t1.scplus != t2.scplus) return t2.scplus - t1.scplus;
				if (t1.won != t2.won) return t2.won - t1.won;
				return t2.idx - t1.idx;
			}
		});
	}

	private void readGame() throws Exception {
		String n1 = nextToken();
		nextToken();
		String n2 = nextToken();
		Team t1 = (Team)names.get(n1);
		Team t2 = (Team)names.get(n2);
		String s = nextToken();
		scores[t1.idx][t2.idx] = s;
		int i1 = s.charAt(0) - '0';
		int i2 = s.charAt(2) - '0';
		t1.scplus += i1; t1.scminus += i2;
		t2.scplus += i2; t2.scminus += i1;
		t1.played++; t2.played++;
		if (i1 < i2) {
			t1.lost++; t2.won++;
			t2.points += 3;
		} else if (i1 > i2) {
			t1.won++; t2.lost++;
			t1.points += 3;
		} else {
			t1.tie++; t2.tie++;
			t1.points++; t2.points++;
		}
	}

	private void printTable() {
		for (int i = 0; i < teams.length; ++i) scores[i][i] = " X ";
		System.out.println("RESULTS:");
		horizLine();

		outch('|');
		for (int i = 0; i < longest; ++i) outch(' ');
		outch('|');
		for (int i = 0; i < teams.length; ++i) {
			String s = teams[i].name;
			if (s.length() >= 3) {
				System.out.print(s.substring(0, 3));
			} else {
				System.out.print(s);
				for (int j = s.length(); j < 3; ++j) outch(' ');
			}
			outch('|');
		}
		outln();
		horizLine();
		for (int t = 0; t < teams.length; ++t) {
			System.out.print('|' + teams[t].name);
			for (int i = teams[t].name.length(); i < longest; ++i) outch(' ');
			outch('|');
			for (int i = 0; i < teams.length; ++i) {
				if (i==t) System.out.print(" X |");
				else if (scores[t][i] == null) System.out.print("   |");
				else System.out.print(scores[t][i] + '|');
			}
			outln();
			horizLine();
		}
		outln();
	}

	private void horizLine() {
		outch('+');
		for (int i = 0; i < longest; ++i) outch('-');
		outch('+');
		for (int i = 0; i < teams.length; ++i) System.out.print("---+");
		outln();
	}

	private void printRank() {
		System.out.println("STANDINGS:");
		System.out.println("----------");
		String[][] tbl = new String[teams.length][8];
		for (int i = 0; i < teams.length; ++i) {
			tbl[i][0] = String.valueOf(i+1) + '.';
			tbl[i][1] = teams[i].name;
			tbl[i][2] = String.valueOf(teams[i].played);
			tbl[i][3] = String.valueOf(teams[i].won);
			tbl[i][4] = String.valueOf(teams[i].tie);
			tbl[i][5] = String.valueOf(teams[i].lost);
			tbl[i][6] = String.valueOf(teams[i].scplus) + ':' + String.valueOf(teams[i].scminus);
			tbl[i][7] = String.valueOf(teams[i].points);
		}
		int[] len = new int[8];
		for (int j = 0; j < 8; ++j) len[j] = 0;
		for (int i = 0; i < teams.length; ++i) {
			for (int j = 0; j < 8; ++j)
				if (tbl[i][j].length() > len[j]) len[j] = tbl[i][j].length();
		}
		for (int i = 0; i < teams.length; ++i) {
			for (int j = 0; j < 8; ++j) {
				if (j!=1) for (int k = tbl[i][j].length(); k < len[j]; ++k) outch(' ');
				System.out.print(tbl[i][j]);
				if (j==1) for (int k = tbl[i][j].length(); k < len[j]; ++k) outch(' ');
				if (j < 7) outch(' ');
			}
			outln();
		}
		outln();
	}
}
