#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define MAXN 5000
#define MAXK 500

int n,k;
char str[MAXN+2][MAXK+2];
int len[MAXN+2];
int aut_back[MAXK+2], aut_len;
char aut_cmp[MAXK+2];

int res;
char res_str[MAXK+2];

/* construct search automaton for 
 (str[0][start], str[0][start+1], ... str[0][len[0]-1]) */
void build_automaton(int start)
{
	int j, tmp;
	aut_len = len[0]-start;
	aut_back[0] = -1;
	aut_back[1] = 0;
	for(j=0; j<aut_len; j++) aut_cmp[j] = str[0][j+start];
	for(j=2; j<aut_len; j++)
	{
		tmp = aut_back[j-1];
		while(tmp>=0 && aut_cmp[j-1] != aut_cmp[tmp]) 
		{
			tmp = aut_back[tmp];
		}
		aut_back[j] = tmp+1;
	}
}

int find_longest(int a)
{
	int i,pos,ret;

	ret=pos=0;
	for(i=0;i<len[a];i++)
	{
		while(pos>=0 && str[a][i]!=aut_cmp[pos]) pos = aut_back[pos];
		pos++;
		if(pos>ret) ret = pos;
	}
	return ret;
}


int main(void)
{
	int i,j,tmp,minlen;
	
	while(1)
	{
		scanf("%d", &n);
		if(n==0) break;
		res = 0; res_str[0]='\0';
		for(i=0;i<n;i++) 
		{
			scanf(" %s ",str[i]);
			len[i] = strlen(str[i]);
/*			printf("%s\n", str[i]);*/
		}
		for(i=0;i<len[0];i++)
		{
			build_automaton(i);
			minlen = aut_len;
			for(j=1;j<n;j++)
			{
				tmp = find_longest(j);
				if(minlen == -1 || tmp<minlen) minlen = tmp;
/*printf("%d %d\n", i, minlen);*/
			}
			if(minlen>res || (res>0 && minlen==res && strcmp(&str[0][i],res_str)<0))
			{
				res = minlen;
				strcpy(res_str, &str[0][i]);
				res_str[res]='\0';
			}
		}
		if(res_str[0]=='\0') printf("IDENTITY LOST\n");
		else printf("%s\n",res_str);
	}
	return 0;
}
	


