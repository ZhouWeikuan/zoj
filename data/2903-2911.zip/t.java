import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.StringTokenizer;

public class theseus {
	StringTokenizer st = new StringTokenizer("");
	BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) throws Exception {
		new theseus().run();
	}
	String nextToken() throws Exception {
		while (!st.hasMoreTokens()) st = new StringTokenizer(input.readLine());
		return st.nextToken();
	}
	int nextInt() throws Exception {
		return Integer.parseInt(nextToken());
	}

	static final char CH_WALL = '#';
	static final char CH_FREE = '.';

	LinkedList queue = new LinkedList();
	char[] map = new char[1<<20];
	int[] dist = new int[1<<20];
	int[] size = new int[20];
	int[] mult = new int[21];
	char mark;
	int dims;
	int mino, thes, swor;

	private void run() throws Exception {
		for (;;) {
			dims = nextInt();
			if (dims <= 0) break;
			mult[0] = 1;
			for (int i = 0; i < dims; ++i) {
				size[i] = nextInt();
				mult[i+1] = size[i] * mult[i];
			}
			readMap(0, dims);
			int best = findPaths();
			System.out.println((best < 0)
					? "No solution. Poor Theseus!"
					: "Theseus needs " + best + " steps.");
		}
	}

	private int findPaths() {
		int best = 0;
		int p;
		map[mino] = CH_WALL;
		mark = '1';
		p = findPath(thes, swor);
		if (p < 0) return p;
		best += p;
		map[mino] = CH_FREE;
		mark = '2';
		p = findPath(swor, mino);
		if (p < 0) return p;
		best += p;
		mark = '3';
		p = findPath(mino, thes);
		if (p < 0) return p; // shold never happen
		return best + p;
	}

	private int findPath(int beg, int end) {
		queue.clear();
		enqueue(beg, 0);
		while (!queue.isEmpty()) {
			int pos = ((Integer)queue.removeFirst()).intValue();
			int d = dist[pos];
			if (pos == end) return d;
			++d;
			for (int i = 0; i < dims; ++i) {
				if ((pos + mult[i])/mult[i+1] == pos/mult[i+1])
					enqueue(pos + mult[i], d);
				if ((pos - mult[i])/mult[i+1] == pos/mult[i+1])
					enqueue(pos - mult[i], d);
			}
		}
		return -1;
	}

	private void enqueue(int pos, int d) {
		if (pos < 0 || pos >= mult[dims]) return;
		if (map[pos] == mark || map[pos] == CH_WALL) return;
		dist[pos] = d;
		queue.addLast(Integer.valueOf(pos));
		map[pos] = mark;
	}

	private void readMap(int offset, int d) throws Exception {
		if (d == 0) return;
		if (d == 1) {
			String s = nextToken();
			for (int i = 0; i < size[0]; ++i) {
				char ch = s.charAt(i);
				if (ch == 'T') thes = offset+i;
				else if (ch == 'M') mino = offset+i;
				else if (ch == 'S') swor = offset+i;
				map[offset+i] = ch;
			}
			return;
		}
		for (int i = 0; i < size[d-1]; ++i) {
			readMap(offset, d-1);
			offset += mult[d-1];
		}
	}
}
