#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXSTOPS 1000
#define MAXNAMELEN 30
#define MAXLINES 1000
#define MAXLINELEN 100

#define MAX(a,b) (((a)>(b))?(a):(b))

int lcnt, scnt;
int linetimes[MAXLINES+2][100];
int ltcnt[MAXLINES+2];
int linestop[MAXLINES+2][MAXLINELEN+2];
int lsoffset[MAXLINES+2][MAXLINELEN+2];
int lscnt[MAXLINES+2];
int stoptime[2][MAXSTOPS+2];
char stopname[MAXSTOPS+2][MAXNAMELEN+2];


int lookup_name(char *name, int add_new)
{
	int i;
	for(i=0;i<scnt;i++)
	{
		if(!strcmp(name, stopname[i])) break;
	}
	if(i==scnt) 
	{
		if(add_new)
		{
			strcpy(stopname[scnt],name);
			scnt++;
		}
		else return -1;
	}
	return i;	
}

int fin[MAXSTOPS+2];

void fill_stop_times(int who)
{
	int i,j,k, h,m,tmp,tmpt, best;
	int firststop, nbwait;
	char tmpname[MAXNAMELEN+2];

	for(i=0;i<scnt;i++) fin[i] = stoptime[who][i]=-1;
	scanf("%d:%d %s",&h, &m, tmpname);
	tmp = lookup_name(tmpname,0);
	if(tmp == -1) return; /*no stop reachable */
	stoptime[who][tmp] = 60*h+m;
	firststop = tmp;

	while(1)
	{
		best = -1;
		for(i=0; i<scnt; i++) if(fin[i]!=1 && stoptime[who][i]!=-1)
		{
			if(best == -1 || stoptime[who][i]<stoptime[who][best]) best = i;
		}
/*printf("%d\n", best);*/
		if(best==-1) break;
		fin[best] = 1;
		for(i=0;i<lcnt;i++)
		{
			for(j=0;j<lscnt[i];j++) if(linestop[i][j] == best)
			{
/*printf("%d %d\n", i, j);*/
				tmpt = stoptime[who][best];
				if(best!=firststop) tmpt+=2;
				tmpt = tmpt%60;
				nbwait = -1;
				for(k=0;k<ltcnt[i];k++)
				{
					tmp = linetimes[i][k] + lsoffset[i][j] + 60;
					if(nbwait == -1 || (tmp-tmpt)%60 < nbwait)
					{
						nbwait = (tmp-tmpt)%60;
					}
				}
				if(nbwait==-1) continue;
				for(k=j+1;k<lscnt[i];k++)
				{
					if(linestop[i][k]==best) break;
					tmpt = stoptime[who][best] + nbwait;
					if(best!=firststop) tmpt+=2;
					tmpt += lsoffset[i][k] - lsoffset[i][j];
					tmp = linestop[i][k];
					if(stoptime[who][tmp]==-1 || tmpt < stoptime[who][tmp]) 
						stoptime[who][tmp] = tmpt;
				}
			}
		}
	}
}

int main(void)
{
	int i,j,tmp,tmpstop, offsettime;
	char tmpname[MAXNAMELEN+2];
	int restime;
	
	while(1)
	{
		scanf("%d ", &lcnt);
		if(lcnt < 0) break;

		scnt = 0;
		for(i=0;i<lcnt;i++)
		{
			offsettime = 0;
			for(j=0;;j++)
			{
				if(j>0) 
				{
					scanf(" %d ",&tmp);
					if(tmp<0) break;
					offsettime += tmp;
				}
				scanf(" %s ",tmpname);
				tmpstop = lookup_name(tmpname,1);
				linestop[i][j] = tmpstop;
				lsoffset[i][j] = offsettime;
			}
			lscnt[i] = j;
			scanf(" %d ",&ltcnt[i]);
			for(j=0;j<ltcnt[i];j++)
			{
				scanf("%d", &linetimes[i][j]);
			}
		}

		fill_stop_times(0);
		fill_stop_times(1);
		
		restime = -1;
		for(i=0;i<scnt;i++)
		{
/*printf("i == %d stopname == %s times == %d %d\n", i, stopname[i], stoptime[0][i], stoptime[1][i]);*/
			if(stoptime[0][i]==-1 || stoptime[1][i]==-1) continue;
			tmp = MAX(stoptime[0][i], stoptime[1][i]);
			if(restime==-1 || restime>tmp)
			{
				restime = tmp;
			}
		}
		if(restime==-1) printf("No connection\n");
		else
		{
			restime = restime%1440;
			printf("%d:%02d\n", restime/60, restime%60);
		}
	}
	
	return 0;
}
	


