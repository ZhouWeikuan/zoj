import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class expr
{
	BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	int vars[] = new int[10];
	String cmd;
	int pos;

	static Map vals = new HashMap();
	static {
		vals.put(Character.valueOf('O'), Integer.valueOf(0));
		vals.put(Character.valueOf('I'), Integer.valueOf(1));
		vals.put(Character.valueOf('V'), Integer.valueOf(5));
		vals.put(Character.valueOf('X'), Integer.valueOf(10));
		vals.put(Character.valueOf('L'), Integer.valueOf(50));
		vals.put(Character.valueOf('C'), Integer.valueOf(100));
		vals.put(Character.valueOf('D'), Integer.valueOf(500));
		vals.put(Character.valueOf('M'), Integer.valueOf(1000));
	}

	static int[] limit = { 1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1 };
	static String[] roms = { "M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I" };


	public static void main(String[] args) throws Exception {
		new expr().run();
	}

	private void run() throws Exception {
		for (;;) {
			cmd = input.readLine();
			if (cmd.charAt(0) == 'Q') {
				System.out.println("Bye");
				return;
			} else if (cmd.charAt(0) == 'R') {
				resetVars();
				System.out.println("Ready");
				continue;
			} else {
				int res = 0;
				int v = cmd.charAt(0) - '0';
				pos = 1;
				while (pos < cmd.length()) {
					boolean neg = (cmd.charAt(pos++) == '-');
					int r = parse();
					if (r < 0) {
						res = -1;
						break;
					}
					if (neg) res -= r; else res += r;
				}
				if (res < 0 || res > 10000) {
					System.out.println("Error");
				} else {
					System.out.println(v + "=" + compose(res));
					vars[v] = res;
				}
			}
		}
	}

	private String compose(int res) {
		String s = "";
		for (int i = 0; i < limit.length; ++i) {
			while (res >= limit[i]) {
				res -= limit[i];
				s += roms[i];
			}
		}
		return (s.length() == 0) ? "O" : s;
	}

	private int parse() {
		char ch = cmd.charAt(pos);
		if (Character.isDigit(ch)) {
			++pos;
			return vars[ch-'0'];
		}
		int res = 0;
		int last = 2000;
		while (pos < cmd.length() && Character.isUpperCase(cmd.charAt(pos))) {
			int n = ((Integer) vals.get(Character.valueOf(cmd.charAt(pos)))).intValue();
			if (n > last) res -= (last<<1);
			res += (last = n);
			++pos;
		}
		return res;
	}

	private void resetVars() {
		for (int i = 0; i < 10; ++i) vars[i] = -1;
	}
}
