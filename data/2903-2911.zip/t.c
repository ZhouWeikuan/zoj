#include <stdio.h>
#include <stdlib.h>

#define MAXDIM 20
#define MAXN 1100000

int d, ni[MAXDIM+2], n;
int type[MAXN+2];
int vis[MAXN+2];
int tpos, mpos, spos;

void ind2coor(int ind, int *coor)
{
	int i;
	
	for(i=0;i<d;i++) 
	{
		coor[i] = ind % ni[i];
		ind /= ni[i];
	}
}

int coor2ind(int *coor)
{
	int i, ret;
	
	ret = 0;
	for(i=d-1;i>=0;i++) 
	{
		ret += coor[i];
		if(i>0) ret*= ni[i-1];
	}
	return ret;
}

int ccmult[MAXDIM+2];
int changecoor(int coor, int cind, int cdif)
{
	return coor+ccmult[cind]*cdif;
}

int q[MAXN+2], qb, qe;
int dist[MAXN+2];

int bfs(int pb, int pe)
{
	int i,tmp,newel;
	int tmpcoor[MAXDIM+2];

	for(i=0;i<n;i++) dist[i]=-1;
	q[0] = pb; qe=1; qb=0; dist[pb]=0;
	while(qe!=qb)
	{
		if(q[qb]==pe) return dist[q[qb]];
		ind2coor(q[qb], tmpcoor);
		for(i=0;i<d;i++)
		{
			if(tmpcoor[i]-1>=0)
			{
				tmp = q[qb];
				newel = changecoor(tmp,i,-1);
				if(dist[newel]==-1 && type[newel]!=0)
				{
					dist[newel] = dist[q[qb]]+1;
					q[qe++] = newel;
				}
			}
			if(tmpcoor[i]+1<ni[i])
			{
				tmp = q[qb];
				newel = changecoor(tmp,i,1);
				if(dist[newel]==-1 && type[newel]!=0)
				{
					dist[newel] = dist[q[qb]]+1;
					q[qe++] = newel;
				}
			}
		}
		qb++;
	}
	return -1;
}

int main(void)
{
	int i,tmp,len,tmp2;
	char tmpc;

	while(1)
	{
		scanf("%d",&d);
		if(d==0) break;
		n=1;
		for(i=0;i<d;i++) 
		{
			scanf("%d",&ni[i]);
			n*=ni[i];
		}
		ccmult[0]=1;
		for(i=1;i<d;i++) ccmult[i] = ccmult[i-1]*ni[i-1];
		for(i=0;i<n;i++)
		{
			scanf(" ");
			tmpc = getchar();
			if(tmpc=='#') type[i] = 0;
			if(tmpc=='.') type[i] = 1;
			if(tmpc=='T') { type[i] = 1; tpos = i; }
			if(tmpc=='S') { type[i] = 1; spos = i; }
			if(tmpc=='M') { type[i] = 1; mpos = i; }
		}
		for(i=0;i<n;i++) vis[i] = 0;
		type[mpos]=0;
		len = bfs(tpos,spos);
		type[mpos]=1;
		tmp = bfs(spos,mpos);
		tmp2 = bfs(mpos,tpos);
		if(tmp == -1 || len == -1 || tmp2==-1) printf("No solution. Poor Theseus!\n");
		else printf("Theseus needs %d steps.\n", len+tmp+tmp2);
	}
	return 0;
}
	


