#include <stdio.h>
#include <stdlib.h>

#define MAX_LIST 200
#define MAX_AMOUNT 10000000

struct money
{
  int value, num;
};

static struct money prod[MAX_LIST], kup[MAX_LIST];
static int prod_len, kup_len;
static int prod_to_pay[MAX_AMOUNT], kup_to_pay[MAX_AMOUNT];
static int kup_sum, prod_sum, tot_sum;

static int
read_list (struct money list[], int *len)
{
  float tmp;
  int l = 0, s = 0, a, k;

  while (1)
    {
      scanf ("%f", &tmp);
      if (tmp < 0)
	{
	  *len = l;

	  if (s >= MAX_AMOUNT)
	    {
	      printf ("Wrong input -- sum is %d\n", s);
	      exit (1);
	    }

	  return s;
	}

      a = (int) (100*tmp + 0.5);
      scanf("%dx", &k);
      s += a * k;

      list[l].value = a;
      list[l++].num = k;
    }
}

static int current[MAX_AMOUNT], orig[MAX_AMOUNT];

static void
payment_options (struct money list[], int len, int sum, int to_pay[])
{
  int i, j, m, v, n, ai, amax = 0, nmax, cten, abest, vbest;

  to_pay[0] = 0;
  for (i = 1; i <= sum; i++)
    to_pay[i] = MAX_AMOUNT;

  for (m = 0; m < len; m++)
    {
      v = list[m].value;
      n = list[m].num;
      if (v == 0 || n == 0)
	continue;

      for (i = 0; i < v; i++)
	{
	  current[i] = 0;
	  orig[i] = to_pay[i];
	}

      nmax = amax + n * v;
      for (i = v; i <= nmax; i++)
	{
	  orig[i] = to_pay[i];
	  cten = to_pay[i - v] + 1;
	  if (cten >= to_pay[i])
	    {
	      current[i] = 0;
	      continue;
	    }

	  /* Hack -- it should be possible to handle this in O(1) in general,
	     somehow. */
	  ai = i - v;
	  if (current[ai] < n)
	    {
	      to_pay[i] = cten;
	      current[i] = current[ai] + 1;
	      continue;
	    }

	  abest = to_pay[i];
	  vbest = 0;
	  for (j = 1; j <= n; j++)
	    {
	      cten = orig[ai] + j;
	      if (cten < abest)
		{
		  abest = cten;
		  vbest = j;
		}
	      ai -= v;
	    }
	  to_pay[i] = abest;
	  current[i] = vbest;
	}
      amax = nmax;
    }
}

int main(void)
{
  float tmp;
  int i, m, am;

  while (1)
    {
      scanf("%f", &tmp);
      if (tmp < 0)
	return 0;
      tot_sum = (int) (100*tmp + 0.5);

      kup_sum = read_list (kup, &kup_len);
      prod_sum = read_list (prod, &prod_len);
      if (kup_sum < tot_sum)
	{
	  printf ("The payment is impossible.\n");
	  continue;
	}
      payment_options (prod, prod_len, prod_sum, prod_to_pay);
      payment_options (kup, kup_len, kup_sum, kup_to_pay);

      m = MAX_AMOUNT;
      i = kup_sum;
      if (i - tot_sum > prod_sum)
	i = tot_sum + prod_sum;

      for (; i >= tot_sum; i--)
	{
	  am = kup_to_pay[i] + prod_to_pay[i - tot_sum];
	  if (am < m)
	    m = am;
	}

      if (m == MAX_AMOUNT)
	printf ("The payment is impossible.\n");
      else
	printf ("%d tenders must be exchanged.\n", m);
    }
}

