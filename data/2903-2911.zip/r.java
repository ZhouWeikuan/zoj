import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.SortedMap;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.TreeSet;

public class railway {
	StringTokenizer st = new StringTokenizer("");
	BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) throws Exception {
		new railway().run();
	}
	String nextToken() throws Exception {
		while (!st.hasMoreTokens()) st = new StringTokenizer(input.readLine());
		return st.nextToken();
	}
	int nextInt() throws Exception {
		return Integer.parseInt(nextToken());
	}

	int ncar, ntrack;
	TreeMap tracks = new TreeMap();
	LinkedList[] store;
	int result[] = new int[1000010];

	private void run() throws Exception {
		for (;;) {
			ncar = nextInt(); ntrack = nextInt();
			if (ncar <= 0) break;
			store = new LinkedList[ntrack];
			tracks.clear();
			for (int i = 0; i < ntrack; ++i) {
				tracks.put(Integer.valueOf(-1-i), Integer.valueOf(i));
				store[i] = new LinkedList();
			}
			if (!splitCars()) {
				System.out.println("Transportation failed");
				continue;
			}
			for (int i = 0; i < ncar; ++i) {
				if (i>0) System.out.print(' ');
				System.out.print(result[i]);
			}
			System.out.println();
			mergeCars();
		}
	}

	private boolean splitCars() throws Exception {
		boolean ok = true;
		for (int i = 0; i < ncar; ++i) {
			int num = nextInt();
			if (!ok) continue;
			SortedMap mp = tracks.headMap(Integer.valueOf(num+1));
			if (mp.isEmpty()) {ok = false; continue;}
			int n = ((Integer)mp.lastKey()).intValue();
			int t = ((Integer)mp.get(Integer.valueOf(n))).intValue();
			store[t].addLast(Integer.valueOf(num));
			result[i] = t+1;
			if (n != num) {
				tracks.remove(Integer.valueOf(n));
				tracks.put(Integer.valueOf(num), Integer.valueOf(t));
			}
		}
		return ok;
	}

	private void mput(Object k, Object v) {
		LinkedList lst = (LinkedList) tracks.get(k);
		if (lst == null) {
			lst = new LinkedList();
			tracks.put(k, lst);
		}
		lst.addLast(v);
	}

	private Object mfirst() {
		Object k = tracks.firstKey();
		LinkedList lst = (LinkedList) tracks.get(k);
		Object r = lst.removeFirst();
		if (lst.isEmpty()) tracks.remove(k);
		return r;
	}

	private void mergeCars() {
		tracks.clear();
		for (int i = 0; i < ntrack; ++i) {
			if (store[i].isEmpty()) continue;
			mput(store[i].getFirst(), Integer.valueOf(i));
		}
		boolean was = false;
		while (!tracks.isEmpty()) {
			Integer ii = (Integer) mfirst();
			int i = ii.intValue();
			Integer n = (Integer) store[i].removeFirst();
			if (was) System.out.print(' ');
			System.out.print(i+1);
			was = true;
			if (store[i].isEmpty()) continue;
			mput((Integer) store[i].getFirst(), ii);
		}
		System.out.println();
	}
}
