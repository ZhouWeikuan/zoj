#include <iostream>
#include <string>
using namespace std;

string digits[] = {"00", "02", "04", "06", "30", "32", "34", "36", "40", "42",
		   "44", "46", "50", "52", "54", "56", "60", "62", "64", "66"};
string zeroes[] = {"", "0", "0", "0", "0", "0", "0", "0000000", "0"};

int main()
{
	int n;
	cin >> n;
	while (n > 0) {
		string ans = "";
		int k=0;
		while (n > 0) {
			int i = n%20;
			ans = digits[i] + zeroes[k] + ans;
			n /= 20;
			k++;
		}
		while (ans[0] == '0')
			ans = ans.substr(1,ans.length());
//		cout << ans << endl;
										// add commas
		k=ans.length()-3;
		while (k>0) {
			ans = ans.substr(0,k)+","+ans.substr(k, ans.length());
			k -= 3;
		}
		cout << ans << endl;

		cin >> n;
	}
	return 0;
}
