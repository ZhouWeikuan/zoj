// TRemainder.cc
// TF solution to Remainde From Our Sponsor
// 2007 ECNA

#include <iostream>
using namespace std;

int KeySize=4,BiggestVal;
int Key[7], Rem[7];

void Convert(int n , bool blanks){
  char a, b, c;

  if(n%100 == 27) 
    c=' ';
  else
    c = (char)(n % 100 - 1 + 'A');
  if((n/100) % 100 == 27) 
    b =' ';
  else
    b = (char)((n/100) % 100 - 1 + 'A');
  if(n/10000 == 27)
    a = ' ';
  else
    a = (char)(n/10000 - 1 + 'A');

  if(blanks)  //print all chars
    cout<<a<<b<<c;
  else{      //suppress trailing blanks
   if(b==' ')
     cout<<a;
   else if (c==' ')
     cout<<a<<b;
   else
     cout<<a<<b<<c;
  }
}


int Decrypt(int n){
  bool OK;

  for(int i=10000; i<BiggestVal; i++){
   OK=true;
   for(int j=0;j<KeySize;j++)
    if(i%Key[j] != Rem[j]){
      OK=false; j=KeySize+1;
    }
   if(OK){ 
    //cout<<"   decrypt: "<<i<<endl;
    return i;
   }
  }
}

int NumDigits(int n){
  int d = 1, m = 1;
  while(m<=n){ 
   d++;
   m *= 10;
  }
  return (d-1);
}

void PickOffRemainders(int n){    //Creates Rem[0..KeySize-1]
  int k, l;

  for(int i=KeySize-1;i>-1; i--){
   k = Key[i];
   l= NumDigits(k);
   //pick off rightnmost l digits of n
   if(i==0) Rem[0]=n;
   else{
     int m = 1;
     for(int j=0; j<l;j++) m *=10;
     Rem[i]= n % m;
     n=n/m;                     //remove digits from n
   }
  }
}

int main(){
   int n, GroupSize, G;

   cin>>n;
   for(int i=0;i<n;i++){
    cin>>GroupSize;
    for(int j=0;j<KeySize;j++)  //get keys
     cin>>Key[j];
//for(int j=0;j<KeySize;j++) cout << Key[j] <<' '; cout<<endl;
    //compute largest group
    int longest = 0;
    for(int j=0;j<KeySize;j++) longest += NumDigits(Key[j]);
    BiggestVal = 1;
    for(int j=0;j<longest;j++) BiggestVal  *= 10;
    for(int j=0;j<GroupSize;j++){
     cin>>G;
//cout<< "***    "<< G <<endl;
     PickOffRemainders(G);
//for(int h=0;h<KeySize;h++) cout << Rem[h] <<' '; cout<<endl;
     if(j<GroupSize-1)
      Convert(Decrypt(G), true);     //don't suppress trailing blanks
     else
      Convert(Decrypt(G),false);     //suppress trailing blanks
    }
    cout<<endl;
   }

return 0;
}
