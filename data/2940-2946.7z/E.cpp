//TLock.cc
// TF SOlution to Once Around The Lock
// 2007 ECNA

#include <iostream>
using namespace std;


int CurrentDir, // -1 = CC, 1 = C
    State,
    CurrentClicks, //total clicks in CurrentDIr
    top;
int x,y,z,n,m;
char d[3];

void PrintStuff(){  //for debugging
   cout<<d<<' '<<m<<": state="<<State<<" top="<<top<<" Dir="<<CurrentDir<<" clicks="<<CurrentClicks<<endl;
}

void Init(){
  CurrentDir = -1;
  top = 0;
  State = 0;
  CurrentClicks = 0;
}

int main(){
  int Case = 1;

  cin>>n;
  while(n>0){
    Init();
//cout<< "Initial state:"<<endl;
//PrintStuff();
    cin>>x>>y>>z;
//cout<<"x="<<x<<" y="<<y<<" z= "<<z<<endl;
    cin>>d;
    while(d[0]!='?'){
     if(strlen(d)==1){    //clockwise turn
      cin>>m;             //get #clicks
      if(CurrentDir==-1){  //last turn was CC, state is 0, 1 or 2
       CurrentDir = 1;
       top -= m;
       while (top<0) top += n;
       CurrentClicks = m;
       if(State==2 && CurrentClicks<=n && top==z) State=3;
       if(State==2 && CurrentClicks>n) State=0;
       if(State==0 && CurrentClicks>=n && top==x) State=1;
       if(State==2 && CurrentClicks>=n && top==x) State=1;
       if(State==1 && CurrentClicks<n) State=0;
       if(State==1 && top!=x) State=0;
      }
      else{                //last turn C, state 0,1,2 or 3
       top -=m;
       while(top<0) top += n;
       CurrentClicks +=  m;
       if(State==0 &&CurrentClicks>=n && top ==x) State=1;
       if(State==1 && top != x) State=0;
       if(State==3 && CurrentClicks>=n && top==x) State=1;
       if(State==3) State=0;
       if(State==2 && CurrentClicks<=n && top==z) State=3;
       if(State==2 && CurrentClicks>=n && top==x) State=1;
       if(State==2 && CurrentClicks>=n) State==0;
      }
     }                    //end of C turn
     else {               //CC turn
      cin>>m;
      if(CurrentDir==-1){  //last turn CC, either state 0, 1 or 2
       top = (top + m)%n;
       CurrentClicks += m;
       if(State==2) State =0;
       if(State==1 && CurrentClicks<=2*n && CurrentClicks >n && top==y) State=2;
      }
      else {             //last turn C, state 0,1,2 or 3
       CurrentDir = -1;
       top = (top+m)%n;
       CurrentClicks =m;
       if(State==2) State=0;
       if(State==1 && CurrentClicks<=2*n && CurrentClicks>n && top==y) State=2;
       if(State==3) State=0;
      }
     }       

//PrintStuff();
      cin>>d;      //get next movement
    }             //end while


    //d=='?'
    if (State==3) cout<<"Case "<<Case++<<": Open"<<endl;
    else          cout<<"Case "<<Case++<<": Closed"<<endl; 

    cin>>n;   // get new lock
  }

return 0;
}
