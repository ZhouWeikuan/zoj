#include <iostream>
#include <string>
using namespace std;

const int MAXD = 1000;
const int MAXW = 50000;

const int HORZ = 0;
const int VERT = 1;
const int DIAG = 2;

char grid[MAXD][MAXD];

class list {
public:
    list(int i, list* n) {
        w = i;
        next = n;
    };
    int w;
    list *next;
};

struct wordt {
    string word;
    int r1, c1, r2, c2;
    int type;
    list *adj;
    bool visited;
    int dnum;
    int best;
} wordList[MAXW];

int check(int i, int& dnum, int prev)
{
    if(wordList[i].visited)
        return wordList[i].dnum;
    wordList[i].visited = true;
    wordList[i].dnum = dnum++;
    for(list* p=wordList[i].adj; p!=0; p=p->next) {
        if (p->w == prev)
            continue;
        int ans = check(p->w, dnum, i);
        if (ans == -1)
            return -1;
        if (ans < wordList[i].best)
            wordList[i].best = ans;
    }
    if (wordList[i].best >= wordList[i].dnum)
        return -1;
    return wordList[i].best;
}

bool check(int nwords)
{
	if (nwords == 1)
		return true;
    if (wordList[0].adj == 0)
        return false;
    wordList[0].visited = true;
    wordList[0].dnum = 0;
    for(int i=1; i<nwords; i++) {
        wordList[i].visited = false;
        wordList[i].best = nwords+1;
    }
    int dnum=1;
    int ans = check(wordList[0].adj->w, dnum, 0);
    if (ans == -1)
        return false;
    for(int i=0; i<nwords; i++)
        if (!wordList[i].visited)
            return false;
    return true;
}
    
void setWordListEntry(int iword, int r1, int r2, int c1, int c2, int type)
{
    wordList[iword].r1=r1;
    wordList[iword].r2=r2;
    wordList[iword].c1=c1;
    wordList[iword].c2=c2;
    wordList[iword].type = type;
}

void getWord(int iword, int n, int m)
{
    int i, j, k, len;
    string s;

    cin >> s;
    for(i=0; i<s.length(); i++)
        if (s[i] > 'Z')
            s[i] += ('A'-'a');
    wordList[iword].word = s;
    wordList[iword].adj = 0;
    len = s.length();
    for(i=0; i<n; i++) {
        for(j=0; j<=m-len; j++) {
            k=0;
            while(k<len && grid[i][j+k] == s[k])
                k++;
            if (k == len) {
                setWordListEntry(iword, i, i, j, j+len-1, HORZ);
                return;
            }
            k=0;
            while(k<len && grid[i][j+k] == s[len-1-k])
                k++;
            if (k == len) {
                setWordListEntry(iword, i, i, j, j+len-1, HORZ);
                return;
            }
        }
    }
    for(j=0; j<m; j++) {
        for(i=0; i<=n-len; i++) {
            k=0;
            while(k<len && grid[i+k][j] == s[k])
                k++;
            if (k == len) {
                setWordListEntry(iword, i, i+len-1, j, j, VERT);
                return;
            }
            k=0;
            while(k<len && grid[i+k][j] == s[len-1-k])
                k++;
            if (k == len) {
                setWordListEntry(iword, i, i+len-1, j, j, VERT);
                return;
            }
        }
    }
    for(i=0; i<=n-len; i++) {
        for(j=0; j<=m-len; j++) {
            k=0;
            while(k<len && grid[i+k][j+k] == s[k])
                k++;
            if (k == len) {
                setWordListEntry(iword, i, i+len-1, j, j+len-1, DIAG);
                return;
            }
            k=0;
            while(k<len && grid[i+k][j+k] == s[len-1-k])
                k++;
            if (k == len) {
                setWordListEntry(iword, i, i+len-1, j, j+len-1, DIAG);
                return;
            }
        }
    }
    for(i=len-1; i<n; i++) {
        for(j=0; j<=m-len; j++) {
            k=0;
            while(k<len && grid[i-k][j+k] == s[k])
                k++;
            if (k == len) {
                setWordListEntry(iword, i-len+1, i, j+len-1, j, DIAG);
                return;
            }
            k=0;
            while(k<len && grid[i-k][j+k] == s[len-1-k])
                k++;
            if (k == len) {
                setWordListEntry(iword, i-len+1, i, j+len-1, j, DIAG);
                return;
            }
        }
    }
    cout << "ERROR: word " << s << " not found" << endl;
    
}

bool horzVertInt(int r1, int c1, int c2, int r3, int r4, int c3)
{
    return (r3 <= r1 && r4 >= r1 && c3 >= c1 && c3 <= c2);
}

bool horzDiagInt(int r1, int c1, int c2, int r3, int r4, int c3, int c4)
{
    if (r3 > r1 || r4 < r1)
        return false;
    int cint = c3+(r1-r3)*(c3-c4)/(r3-r4);
    return (cint >= c1 && cint <= c2);
}

bool vertDiagInt(int r1, int r2, int c1, int r3, int r4, int c3, int c4)
{
    if (c3 > c4) {
        int temp = c3;
        c3 = c4;
        c4 = temp;
        temp = r3;
        r3 = r4;
        r4 = temp;
    }
    if (c3 > c1 || c4 < c1)
        return false;
    int rint = r3+(c1-c3)*(r3-r4)/(c3-c4);
    return (rint >= r1 && rint <= r2);
}

bool diagDiagInt(int r1, int r2, int c1, int c2, int r3, int r4, int c3, int c4)
{
    if ((r1+c1)%2 != (r3+c3)%2)
        return false;
    bool downright1 = (c2>c1);
    bool downright3 = (c4>c3);
    if (downright1 && downright3) {
        if (r1-c1 != r3-c3)
            return false;
        return ((r1>=r3 && r1 <= r4) || (r3 >= r1 && r3<=r2));
    }
    else if (!downright1 && !downright3) {
        if (r1+c1 != r3+c3)
            return false;
        return ((r1>=r3 && r1 <= r4) || (r3 >= r1 && r3<=r2));
    }
    else if (downright1 && !downright3) {
        int u = (r3+c3-(r1+c1))/2;
        if (u < 0 || u > (r2-r1))
            return false;
        int t = (r1-c1-(r3-c3))/2;
        return (t>=0 && t<=(r4-r3));
    }
    else {
        int u = (r3-c3-(r1-c1))/2;
        if (u < 0 || u > (r2-r1))
            return false;
        int t = (r1+c1-(r3+c3))/2;
        return (t>=0 && t<=(r4-r3));
    }
}

void addToLists(int iword, int i)
{
    wordList[iword].adj = new list(i, wordList[iword].adj);
    wordList[i].adj = new list(iword, wordList[i].adj);
}

void checkIntersect(int iword)
{
    int r1 = wordList[iword].r1;
    int c1 = wordList[iword].c1;
    int r2 = wordList[iword].r2;
    int c2 = wordList[iword].c2;
    int type = wordList[iword].type;
    for(int i=0; i<iword; i++) {
        int r3 = wordList[i].r1;
        int c3 = wordList[i].c1;
        int r4 = wordList[i].r2;
        int c4 = wordList[i].c2;
        int type2 = wordList[i].type;
        switch (type) {
        case HORZ :
            switch (type2) {
            case HORZ :
                if ((r1==r3) && ((c3 >= c1 && c3 <= c2) || (c1 >= c3 && c1 <= c4))) {
                    addToLists(iword, i);
                }
                break;
            case VERT :
                if (horzVertInt(r1, c1, c2, r3, r4, c3)) {
                    addToLists(iword, i);
                }
                break;
            case DIAG :
                if (horzDiagInt(r1, c1, c2, r3, r4, c3, c4)) {
                    addToLists(iword, i);
                }
                break;
            }
            break;
        case VERT :
            switch (type2) {
            case HORZ :
                if (horzVertInt(r3, c3, c4, r1, r2, c1)) {
                    addToLists(iword, i);
                }
                break;
            case VERT :
                if ((c1==c3) && ((r3 >= r1 && r3 <= r2) || (r1 >= r3 && r1 <= r4))) {
                    addToLists(iword, i);
                }
                break;
            case DIAG :
                if (vertDiagInt(r1, r2, c1, r3, r4, c3, c4)) {
                    addToLists(iword, i);
                }
                break;
            }
            break;
        case DIAG :
            switch (type2) {
            case HORZ :
                if (horzDiagInt(r3, c3, c4, r1, r2, c1, c2)) {
                    addToLists(iword, i);
                }
                break;
            case VERT :
                if (vertDiagInt(r3, r4, c3, r1, r2, c1, c2)) {
                    addToLists(iword, i);
                }
                break;
            case DIAG :
                if (diagDiagInt(r1, r2, c1, c2, r3, r4, c3, c4) ){
                    addToLists(iword, i);
                }
                break;
            }
        }
    }
}
    
int main()
{
    int n, m, nwords, i, j;
    cin >> n >> m >> nwords;
    while (n > 0) {
        for(i=0; i<n; i++)
            for(j=0; j<m; j++)
                cin >> grid[i][j];
        for(i=0; i<nwords; i++) {
            getWord(i, n, m);
            checkIntersect(i);
        }

        if (check(nwords))
            cout << "Yes" << endl;
        else
            cout << "No" << endl;


        cin >> n >> m >> nwords;
    }
    return 0;
}
